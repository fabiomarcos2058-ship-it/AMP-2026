extends Control

func _ready() -> void:
	$Nave.play()

func _on_jogar_pressed() -> void:
	get_tree().change_scene_to_file("res://Cenas/jogo.tscn")


func _on_sair_pressed() -> void:
	get_tree().quit()
