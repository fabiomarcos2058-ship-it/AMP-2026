extends Node

signal pontos_alterados(pontos: int)
signal vidas_alteradas(vidas: int)
signal jogador_morreu()

var ultima_pontuacao := 0
