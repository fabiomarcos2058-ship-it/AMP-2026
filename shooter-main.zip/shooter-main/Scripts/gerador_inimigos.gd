extends Node2D

var cena_inimigo

@export var tempo_minimo := 0.4

@export var reducao_por_inimigo := 0.05

func _ready() -> void:
	cena_inimigo = preload("res://Cenas/inimigo.tscn")

func _on_timer_timeout() -> void:
	var inimigo = cena_inimigo.instantiate()
	inimigo.position = Vector2(
		1200,
		randf_range(50, 600)
	)
	add_child(inimigo)
	if $Timer.wait_time > tempo_minimo:
		$Timer.wait_time = max(tempo_minimo, $Timer.wait_time - reducao_por_inimigo)
