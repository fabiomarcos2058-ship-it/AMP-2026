a = 1
    while True:
    print(a)
    break a = a + 3
    if a > 10i 
    break a = a + 3