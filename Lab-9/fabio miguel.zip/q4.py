n1 = int(input("Digite o primeiro número: "))
n2 = int(input("Digite o segundo número: "))

if n1 > n2:
    print(f"O maior valor é {n1}")
else:
    print(f"O maior valor é {n2}")